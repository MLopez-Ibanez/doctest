
library(roxygen2)
dedent <- function (x) gsub("\n\\s+", "\n", x)
